﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jsTools.Highcharts;

namespace AspControls
{
    public partial class ChartTest3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Highcharts highcharts = new Highcharts();

            highcharts.title = new jsTools.Highcharts.Title();
            highcharts.title.text = "Monthly Average Temperature";
            highcharts.title.x = -20;

            highcharts.credits = new Credits();
            highcharts.credits.enabled = false;

            highcharts.subtitle = new jsTools.Highcharts.Title();
            highcharts.subtitle.text = "Source: WorldClimate.com";
            highcharts.subtitle.x = -20;

            highcharts.xAxis = new Axis[1];
            highcharts.xAxis[0] = new Axis();
            highcharts.xAxis[0].categories = new string[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

            highcharts.yAxis = new Axis[1];
            highcharts.yAxis[0] = new Axis();
            highcharts.yAxis[0].title = new ATitle();
            highcharts.yAxis[0].title.text = "Temperature (°C)";
            highcharts.yAxis[0].plotLines = new Plot[1];
            highcharts.yAxis[0].plotLines[0] = new Plot();
            highcharts.yAxis[0].plotLines[0].value = 0;
            highcharts.yAxis[0].plotLines[0].width = 1;
            highcharts.yAxis[0].plotLines[0].Color = System.Drawing.ColorTranslator.FromHtml("#808080");

            highcharts.tooltip = new Tooltip();
            highcharts.tooltip.valueSuffix = "°C";

            highcharts.legend = new Legend();
            highcharts.legend.layout = "vertical";
            highcharts.legend.align = "right";
            highcharts.legend.verticalAlign = "middle";
            highcharts.legend.borderWidth = 0;

            Random rnd = new Random();

            highcharts.series = new Series[4];

            for (int i = 0; i < highcharts.series.Length; i++)
            {
                highcharts.series[i] = new SeriesLine();
                highcharts.series[i].name = "City_" + i;
                highcharts.series[i].data = new double[12];

                for (int j = 0; j < highcharts.series[i].data.Length; j++)
                    ((double[])highcharts.series[i].data)[j] = R(rnd.NextDouble(), 5, 25);
            }

            jsChart1.highcharts = highcharts;
        }

        static double R(double v, double min, double max)
        {
            double r = max - min;
            r = r * v;
            r = min + r;
            r = Math.Round(r, 1);
            return r;
        }
    }
}