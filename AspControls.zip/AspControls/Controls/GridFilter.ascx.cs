﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace AspControls.Controls
{
    public partial class GridFilter : System.Web.UI.UserControl
    {
        public Unit Height
        {
            get { return RadComboBox1.Height; }
            set { RadComboBox1.Height = value; }
        }

        public Unit Width
        {
            get { return RadComboBox1.Width; }
            set { RadComboBox1.Width = value; }
        }

        public string CssClass
        {
            get { return RadComboBox1.CssClass; }
            set { RadComboBox1.CssClass = value; }
        }

        public bool AutoPostBack
        {
            get { return RadComboBox1.AutoPostBack; }
            set { RadComboBox1.AutoPostBack = value; }
        }

        public CssStyleCollection Style
        {
            get
            {
                return
                    RadComboBox1.Style;
            }
        }

        public string FieldName { get; set; }

        public string Label
        {
            get { return Label1.Text; }
            set { Label1.Text = value; }
        }

        public string GridViewID { get; set; }

        private GridView gv;

        private int rn
        {
            get { return HiddenField1.Value.ConvertItTo<int>(); }
            set { HiddenField1.Value = value.ToString(); }
        }

        protected void Page_Init(object sender, EventArgs e)
        {

            gv = ASP_Utils.FindControl(Page, GridViewID) as GridView;
            if (gv == null)
                return;

            gv.DataBound += Gr_DataBound;

        }

        private void Gr_DataBound(object sender, EventArgs e)
        {


            for (int index = 0; index < gv.Columns.Count; index++)
            {
                BoundField o = gv.Columns[index] as BoundField;
                if (o != null && string.Equals(o.DataField, FieldName, StringComparison.CurrentCultureIgnoreCase))
                    rn = index;

            }

            var ss = (from GridViewRow o in gv.Rows select o.Cells[rn].Text).ToList();
            ss = ss.Distinct().ToList();

            List<RadComboBoxItem> remList = new List<RadComboBoxItem>();

            foreach (RadComboBoxItem o in RadComboBox1.Items)
            {
                if (!o.Text.In(ss.ToArray()))
                    remList.Add(o);// RadComboBox1.Items.Remove(o);
                else
                    ss.Remove(o.Text);
            }

            foreach (RadComboBoxItem o in remList)
            {
                RadComboBox1.Items.Remove(o);
            }

            foreach (string s in ss)
            {
                RadComboBoxItem r = new RadComboBoxItem { Text = s, Checked = true };
                RadComboBox1.Items.Add(r);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            if (gv != null)
            {
                foreach (GridViewRow r in gv.Rows)
                {
                    r.Visible = true;
                }

            }
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            var ss = new List<string>();

            foreach (RadComboBoxItem i in RadComboBox1.Items)
            {
                if (i.Checked)
                    ss.Add(i.Text);
            }


            foreach (GridViewRow r in gv.Rows)
            {
                if (r.Visible)
                    r.Visible = r.Cells[rn].Text.In(ss.ToArray());
            }
        }


    }
}