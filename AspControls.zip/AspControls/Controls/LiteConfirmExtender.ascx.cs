﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace AspControls.Controls
{
    public partial class LiteConfirmExtender : System.Web.UI.UserControl
    {
        public string TargetControlID { get; set; }

        string _MessageText = "Are you sure?";

        public string MessageText { get { return _MessageText; } set { _MessageText = value; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TargetControlID))
                throw new DataException("Не задан TargetControlID");

            var bt = Parent.FindControl(TargetControlID) as Button;
            if (bt == null)
                throw new DataException("Не найден элемент TargetControlID : " + TargetControlID + ".");
            bt.OnClientClick = "return confirm('" + MessageText + "' )";
        }
    }
}