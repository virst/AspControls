﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AspControls.Controls
{
    public partial class FixedHeaderGridExpander : System.Web.UI.UserControl
    {
        public string GridViewID { get; set; }

        string _BackgroundColor = "white";

        public string BackgroundColor
        {
            get { return _BackgroundColor; }
            set { _BackgroundColor = value; }
        }

        private GridView GridView1;



        protected void Page_Init(object sender, EventArgs e)
        {
            GridView1 = Parent.FindControl(GridViewID) as GridView;

            if (GridView1 == null)
                return;

            Page.PreLoad += Page_PreLoad;

            GridView1.RowDataBound += GridView1_RowDataBound;
        }

        private void Page_PreLoad(object sender, EventArgs e)
        {
            if (GridView1 == null)
                return;


            int n = GridView1.Parent.Controls.IndexOf(GridView1);
            GridView1.Parent.Controls.AddAt(n, Panel1);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //  Parent.Controls.AddAt();

            if (GridView1 == null)
                return;

            GridView1.UseAccessibleHeader = true;
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            GridView1.HeaderRow.ID = "trz";
            GridView1.HeaderRow.ClientIDMode = ClientIDMode.AutoID;
            GridView1.BorderWidth = 0;
        }

        private int hrn = 0;
        private int rn = 0;

        private void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                hrn++;
                for (int i = 0; i < e.Row.Cells.Count; i++)
                    e.Row.Cells[i].ID = "h_" + hrn + "_" + i;
            }

            if (e.Row.RowType == DataControlRowType.DataRow && rn == 0)
            {
                rn++;
                for (int i = 0; i < e.Row.Cells.Count; i++)
                    e.Row.Cells[i].ID = "r_" + i;
            }

            e.Row.Style["border-width"] = "1px";
            e.Row.Style["border-style"] = "solid";

            for (int i = 0; i < e.Row.Cells.Count; i++)
            {
                 
                e.Row.Cells[i].Style["border-width"] = "1px";
                e.Row.Cells[i].Style["border-style"] = "solid";         
            }
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            Src = "";

            if (GridView1.Rows.Count == 0)
                return;

            Src = "$( document ).ready(function() { \n";

            for (int i = 0; i < GridView1.HeaderRow.Cells.Count; i++)
            {
                Src += String.Format("   $('#{0}').width( $('#{1}').width() ); \n", GridView1.HeaderRow.Cells[i].ClientID, GridView1.Rows[0].Cells[i].ClientID);

                Src += String.Format("   $('#{1}').width( $('#{0}').width() ); \n", GridView1.HeaderRow.Cells[i].ClientID, GridView1.Rows[0].Cells[i].ClientID);
            }

            Src += String.Format(" var o2 = $('#{0}').offset(); \n", GridView1.ClientID);
            Src += String.Format(" var o1 = $('#{0}').offset(); \n", GridView1.HeaderRow.ClientID);

            Src += String.Format(" $('#{0}').parent().css('left', o2.left); \n", GridView1.HeaderRow.ClientID);

            Src += String.Format(" $('#{0}').height( $('#{1}').height() + 2 );  \n ", Panel1.ClientID,
        GridView1.HeaderRow.ClientID);


            Src += String.Format(" $('#{0}').parent().css('position', 'fixed'); \n", GridView1.HeaderRow.ClientID);
            Src += String.Format(" $('#{0}').parent().css('background-color', 'white'); \n", GridView1.HeaderRow.ClientID);
            Src += String.Format(" $('#{0}').parent().css('top', o1.top ); \n", GridView1.HeaderRow.ClientID);

            Src += "});";

            Label1.Text = string.Format("<script> {0}  </script> ", Src);

        }

        protected string Src;
    }
}