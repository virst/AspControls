﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AspControls.Controls
{
    public partial class GridRowClickExtender : System.Web.UI.UserControl
    {
        public string TargetControlId { get; set; }

        public string ToolTip { get; set; }


        protected void Page_Load(object sender, EventArgs e)
        {
            var gv = Parent.FindControl(TargetControlId) as GridView;
            gv.RowDataBound += Gv_RowDataBound;

        }

        private void Gv_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow) // && !e.Row.RowState.HasFlag(DataControlRowState.Selected))
            {
                //каждой строке даём отрибут onclick, чтобы выбрать запись
                e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(sender as Control, "Select$" + e.Row.RowIndex);
                e.Row.ToolTip = this.ToolTip;
            }
        }
    }
}