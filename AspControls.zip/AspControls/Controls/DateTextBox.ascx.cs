﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AspControls.Controls
{
    public partial class DateTextBox : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var t = tbFiltDate.Style;

            
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            // Style = "cursor: pointer"

            if (this.Enabled)
            {
                string src = string.Format("document.getElementById('{0}').value = '';", tbFiltDate.ClientID);
                Label1.Attributes.Add("onclick", src);
                Label1.ForeColor = Color.Red;
                Label1.Style["cursor"] = "pointer";
                Label1.ToolTip = "Очистить";
            }
            else
            {
                Label1.ForeColor = Color.LightGray;
                Label1.Attributes.Remove("onclick");
                Label1.Style["cursor"] = "auto";
                Label1.ToolTip = "";
            }
        }

        public string Text
        {
            get { return tbFiltDate.Text; }
            set { tbFiltDate.Text = value; }
        }

        public bool ShowX
        {
            get { return Label1.Visible; }
            set { Label1.Visible = value; }
        }

        public DateTime? date
        {
            get
            {
                if (this.Text == "")
                    return null;
                return Convert.ToDateTime(this.Text);
            }
        }

        public bool Enabled
        {
            get { return tbFiltDate.Enabled; }
            set { tbFiltDate.Enabled = value; }
        }

        public Unit Height
        {
            get { return Panel1.Height; }
            set { Panel1.Height = value; }
        }

        public Unit Width
        {
            get { return Panel1.Width; }
            set { Panel1.Width = value; }
        }

        public string CssClass
        {
            get { return tbFiltDate.CssClass; }
            set { tbFiltDate.CssClass = value; }
        }

        public bool AutoPostBack
        {
            get { return tbFiltDate.AutoPostBack; }
            set { tbFiltDate.AutoPostBack = value; }
        }

        public CssStyleCollection Style
        {
            get
            {
                return
                    tbFiltDate.Style;
            }
        }
    }
}