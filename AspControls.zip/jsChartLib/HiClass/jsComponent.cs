﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web;

namespace jsTools
{

    public class jsComponent
    {
        public override string ToString()
        {
            string r = "{";

            foreach (var d in this.GetType().GetFields())
            {
                var v = d.GetValue(this);

                if (v == null)
                    continue;              

                r += d.Name + " : " + MyToStr(v) + " ,\n";
            }

            r = r.Trim('\n');
            r = r.Trim(',');

            r += "} ";
            return r;

        }

        string MyToStr(object o)
        {
            if (o is string)
                return "'" + o + "'";

            if (o is double)
                return ((double)o).ToString(CultureInfo.CreateSpecificCulture("en-US"));

            if (o is Color)
                return "'" + HexConverter((Color)o) + "'" ;

            if (o is bool)
                return o.ToString().ToLower();

            if (o is Array)
            {
                string r = "[";

                foreach(var ob in o as Array)
                {
                    r += MyToStr(ob) + ",";
                }

                r = r.Trim(',');

                return r + "]";
            }

            return o.ToString();
        }

        private static String HexConverter(System.Drawing.Color c)
        {
            return "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
        }

        private static String RGBConverter(System.Drawing.Color c)
        {
            return "RGB(" + c.R.ToString() + "," + c.G.ToString() + "," + c.B.ToString() + ")";
        }
    }
}