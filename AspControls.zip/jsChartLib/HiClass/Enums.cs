﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace jsChartLib.HiClass.Enums
{
    enum Days { Sat, Sun, Mon, Tue, Wed, Thu, Fri };  
}
