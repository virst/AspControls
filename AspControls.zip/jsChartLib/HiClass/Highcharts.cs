using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;

namespace jsTools.Highcharts
{

    /// <summary>
    /// Highcharts is a charting library written in pure JavaScript, offering an easy way of 
    /// adding doubleeractive charts to your web site or web application. Highcharts currently 
    /// supports line, spline, area, areaspline, column, bar, pie, scatter, angular gauges, 
    /// arearange, areasplinerange, columnrange, bubble, box plot, error bars, funnel, 
    /// waterfall and polar chart types.
    /// (http://api.highcharts.com/highcharts/accessibility)
    /// </summary>
    public class Highcharts : jsComponent
    {
        public Accessibility accessibility;
        public Chart chart;
        public Color[] colors;
       // public Color color;
        public Credits credits;
        public Data data;
        public string defs;
        public Drilldown drilldown;
        public Exporting exporting;
        public Labels labels;
        public Legend legend;
        public Loading loading;
        public Navigation navigation;
        public Nodata noData;
        public Pane pane;
        public Plotoptions plotOptions;
        public Responsive responsive;
        public Series[] series;
        public Title subtitle;
        public Title title;
        public Tooltip tooltip;
        public Axis[] xAxis;
        public Axis[] yAxis;
        public Axis zAxis;

    }

    public class Accessibility : jsComponent
    {
        public bool? describeSingleSeries = null;
        public bool? enabled = null;
        public KeyboardNavigation keyboardNavigation = null;
        string onTableAnchorClick = null;
        string podoubleDateFormat = null;
        string podoubleDateFormatter = null;
        string podoubleDescriptionFormatter = null;
        boolDouble podoubleDescriptionThreshold = null;
        string screenReaderSectionFormatter = null;
        string seriesDescriptionFormatter = null;


    }

    public class KeyboardNavigation : jsComponent
    {
        public bool? enabled = null;
        public bool? skipNullPodoubles = null;
    }

    public class boolDouble : jsComponent
    {
        object val = null;
        public boolDouble(double? v)
        {
            val = null;
        }

        public boolDouble(bool? v)
        {
            val = null;
        }

        public override string ToString()
        {
            return val.ToString();
        }
    }

    public class Chart : jsComponent
    {
        public bool? booldouble = null;
        public bool? animation = null;
        public Color? backgroundColor = null;
        public Color? borderColor = null;
        public double? borderRadius = null;
        public double? borderWidth = null;
        public string className = null;
        public double? colorCount = null;
        public string defaultSeriesType = null;
        public string description = null;
        public Events events = null;
        public double? height = null;
        public bool? ignoreHiddenSeries = null;
        public bool? inverted = null;
        public string margin = null;
        public double? marginBottom = null;
        public double? marginLeft = null;
        public double? marginRight = null;
        public double? margdoubleop = null;
        public Options3d options3d = null;
        public string panKey = null;
        public bool? panning = null;
        public string pinchType = null;
        public Color? plotBackgroundColor = null;
        public string plotBackgroundImage = null;
        public Color? plotBorderColor = null;
        public double? plotBorderWidth = null;
        public bool? plotShadow = null;
        public bool? polar = null;
        public bool? reflow = null;
        public string renderTo = null;
        public ResetZoomButton resetZoomButton = null;
        public Color? selectionMarkerFill = null;
        public bool? shadow = null;
        public bool? showAxes = null;
        public double[] spacing = null;
        public double? spacingBottom = null;
        public double? spacingLeft = null;
        public double? spacingRight = null;
        public double? spacingTop = null;
        public string style = null;
        public string type = null;
        public string typeDescription = null;
        public double? width = null;
        public string zoomType = null;



    }

    public class ResetZoomButton : jsComponent
    {
        public string position = null;
        public string relativeTo = null;
        public string theme = null;
    }

    public class Options3d : jsComponent
    {
        public double? alpha = null;
        public double? beta = null;
        public double? depth = null;
        public bool? enabled = null;
        public bool? fitToPlot = null;
        public Frame frame = null;
        public double? viewDistance = null;

    }

    public class Frame : jsComponent
    {
        public Bnt back;
        public Bnt bottom;
        public Bnt side;
    }

    public class Bnt : jsComponent
    {
        public Color? Color = null;
        public double? size = null;
    }

    public class Events : jsComponent
    {
        public string addSeries = null;
        public string afterPrdouble = null;
        public string beforePrdouble = null;
        public string click = null;
        public string drilldown = null;
        public string drillup = null;
        public string drillupall = null;
        public string load = null;
        public string redraw = null;
        public string selection = null;

    }

    public class Credits : jsComponent
    {
        public bool? enabled = null;
        public string href = null;
        public string position = null;
        public string style = null;
        public string text = null;
    }

    public class Data : jsComponent
    {
        public string[][] columns = null;
        public string complete = null;
        public string csv = null;
        public string dateFormat = null;
        public string decimalPodouble = null;
        public double? endColumn = null;
        public double? endRow = null;
        public bool? firstRowAsNames = null;
        public string googleSpreadsheetKey = null;
        public string googleSpreadsheetWorksheet = null;
        public string itemDelimiter = null;
        public string lineDelimiter = null;
        public string parseDate = null;
        public string parsed = null;
        public string[][] rows = null;
        public string[] seriesMapping = null;
        public double? startColumn = null;
        public double? startRow = null;
        public bool? switchRowsAndColumns = null;
        public string table = null;
    }

    public class Drilldown : jsComponent
    {
        public string activeAxisLabelStyle = null;
        public string activeDataLabelStyle = null;
        public bool? allowPodoubleDrilldown = null;
        public string animation = null;
        public DrillUpButton drillUpButton = null;
        public string[] series = null;
    }

    public class DrillUpButton : jsComponent
    {
        public string position = null;
        public string relativeTo = null;
        public string theme = null;
    }

    public class Exporting : jsComponent
    {
        public bool? allowHTML = null;
        public Buttons buttons = null;
        public string chartOptions = null;
        public bool? enabled = null;
        public string error = null;
        public bool? fallbackToExportServer = null;
        public string filename = null;
        public string formAttributes = null;
        public string libURL = null;
        public double? prdoubleMaxWidth = null;
        public double? scale = null;
        public double? sourceHeight = null;
        public double? sourceWidth = null;
        public string type = null;
        public string url = null;
        public double? width = null;
    }

    public class Buttons : jsComponent
    {
        public ContextButton contextButton = null;
    }

    public class ContextButton : jsComponent
    {
        public string align = null;
        public bool? enabled = null;
        public double? height = null;
        public string menuItems = null;
        public string onclick = null;
        public string symbol = null;
        public Color? symbolFill = null;
        public double? symbolSize = null;
        public Color? symbolStroke = null;
        public double? symbolStrokeWidth = null;
        public double? symbolX = null;
        public double? symbolY = null;
        public string text = null;
        public string theme = null;
        public string verticalAlign = null;
        public double? width = null;
        public double? x = null;
        public double? y = null;
    }

    public class Labels : jsComponent
    {
        public Item[] items = null;
        public string style = null;
    }

    public class Item : jsComponent
    {
        public string html = null;
        public string style = null;
    }

    public class Legend : jsComponent
    {
        public string align = null;
        public Color? backgroundColor = null;
        public Color? borderColor = null;
        public double? borderRadius = null;
        public double? borderWidth = null;
        public bool? enabled = null;
        public bool? floating = null;
        public double? itemDistance = null;
        public string itemHiddenStyle = null;
        public string itemHoverStyle = null;
        public double? itemMarginBottom = null;
        public double? itemMargdoubleop = null;
        public string itemStyle = null;
        public double? itemWidth = null;
        public string labelFormat = null;
        public string labelFormatter = null;
        public string layout = null;
        public double? lineHeight = null;
        public double? margin = null;
        public double? maxHeight = null;
        public LNavigation navigation = null;
        public double? padding = null;
        public bool? reversed = null;
        public bool? rtl = null;
        public bool? shadow = null;
        public string style = null;
        public double? symbolHeight = null;
        public double? symbolPadding = null;
        public double? symbolRadius = null;
        public double? symbolWidth = null;
        public LTitle title = null;
        public bool? useHTML = null;
        public string verticalAlign = null;
        public double? width;
        public double? x = null;
        public double? y = null;
    }

    public class LNavigation : jsComponent
    {
        public Color? activeColor = null;
        public bool? animation = null;
        public double? arrowSize = null;
        public bool? enabled = null;
        public Color? inactiveColor = null;
        public string style = null;
    }

    public class LTitle : jsComponent
    {
        public string style = null;
        public string text = null;
    }

    public class Loading : jsComponent
    {
        public double? hideDuration = null;
        public string labelStyle = null;
        public double? showDuration = null;
        public string style = null;
    }

    public class Navigation : jsComponent
    {
        public ButtonOptions buttonOptions = null;
        public string menuItemHoverStyle = null;
        public string menuItemStyle = null;
        public string menuStyle = null;
    }

    public class ButtonOptions : jsComponent
    {
        public string align = null;
        public bool? enabled = null;
        public double? height = null;
        public Color? symbolFill = null;
        public double? symbolSize = null;
        public Color? symbolStroke = null;
        public double? symbolStrokeWidth = null;
        public double? symbolX = null;
        public double? symbolY = null;
        public string text = null;
        public string theme = null;
        public string verticalAlign = null;
        public double? width = null;
        public double? y = null;
    }

    public class Nodata : jsComponent
    {
        public string attr = null;
        public string position = null;
        public string style = null;
        public bool? useHTML = null;
    }

    public class Pane : jsComponent
    {
        public Background background = null;
        public string center = null;
        public string endAngle = null;
        public string size = null;
        public string startAngle = null;
    }

    public class Background : jsComponent
    {
        public Color? backgroundColor = null;
        public Color? borderColor = null;
        public double? borderWidth = null;
        public string className = null;
        public double? innerRadius = null;
        public string outerRadius = null;
        public string shape = null;
    }

    public class Plotoptions : jsComponent
    {
        //!!!
    }

    public class Responsive : jsComponent
    {
        public Rules[] rules = null;
    }

    public class Rules : jsComponent
    {
        public string chartOptions = null;
        public Condition condition = null;

    }

    public class Condition : jsComponent
    {
        public string callback = null;
        public double? maxHeight = null;
        public double? maxWidth = null;
        public double? minHeight = null;
        public double? minWidth = null;
    }


    public class Title : jsComponent
    {
        public string align = null;
        public bool? floating = null;
        public string style = null;
        public string text = null;
        public bool? useHTML = null;
        public string verticalAlign = null;
        public double? widthAdjust = null;
        public double? x = null;
        public double? y = null;
    }

    public class Tooltip : jsComponent
    {
        public bool? animation = null;
        public Color? backgroundColor = null;
        public Color? borderColor = null;
        public double? borderRadius = null;
        public double? borderWidth = null;
        public string crosshairs = null;
        public string dateTimeLabelFormats = null;
        public bool? enabled = null;
        public bool? followPodoubleer = null;
        public bool? followTouchMove = null;
        public string footerFormat = null;
        public string formatter = null;
        public string headerFormat = null;
        public double? hideDelay = null;
        public double? padding = null;
        public string podoubleFormat = null;
        public string podoubleFormatter = null;
        public string positioner = null;
        public bool? shadow = null;
        public string shape = null;
        public bool? shared = null;
        public string snap = null;
        public bool? split = null;
        public string style = null;
        public bool? useHTML = null;
        public string valueDecimals = null;
        public string valuePrefix = null;
        public string valueSuffix = null;
        public string xDateFormat = null;
    }


}
